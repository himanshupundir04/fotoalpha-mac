'use server';

/**
 * Group Photos - Genkit AI Flow
 * Groups photos based on people and events.
 */

import { ai } from '../genkit.js'; // Adjust path if needed
import { z } from 'genkit';

const GroupPhotosInputSchema = z.object({
  photoDataUris: z
    .array(z.string())
    .describe(
      'An array of photo data URIs in format: data:<mimetype>;base64,<encoded_data>.'
    ),
});

const PhotoGroupSchema = z.object({
  label: z
    .string()
    .describe('A label for the group like "Getting Ready", "Bride & Groom", etc.'),
  photoIndices: z
    .array(z.number())
    .describe(
      'The indices of the photos (from the input array) that belong to this group.'
    ),
});

const GroupPhotosOutputSchema = z.object({
  groups: z.array(PhotoGroupSchema).describe('An array of grouped photos.'),
});

export async function groupPhotos(input) {
  return groupPhotosFlow(input);
}

const prompt = ai.definePrompt({
  name: 'groupPhotosPrompt',
  input: { schema: GroupPhotosInputSchema },
  output: { schema: GroupPhotosOutputSchema },
  prompt: `You are an expert photo album curator. Your task is to group a collection of photos based on the events taking place and the people present.

Analyze the following images:
{{#each photoDataUris}}
Image {{@index}}: {{media url=this}}
{{/each}}

Identify distinct events (e.g., "Getting Ready", "Ceremony", "Reception") and recurring people. Create groups for these. For individuals, use labels like "Person 1", "Person 2". For groups of people, use labels like "Bride & Groom" or "Family Photos".

Return a list of groups, where each group has a label and a list of the indices of the photos belonging to that group. A single photo can belong to multiple groups.
`,
});

const groupPhotosFlow = ai.defineFlow(
  {
    name: 'groupPhotosFlow',
    inputSchema: GroupPhotosInputSchema,
    outputSchema: GroupPhotosOutputSchema,
  },
  async (input) => {
    const { output } = await prompt(input);
    return output;
  }
);
