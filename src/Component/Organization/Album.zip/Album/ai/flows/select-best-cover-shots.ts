'use server';

/**
 * @fileOverview This file contains the Genkit flow for selecting the best cover shot for an album.
 *
 * - selectBestCoverShots - A function that takes an array of image URLs and returns the best one for the album cover.
 */

import { ai } from '../genkit.js';
import { z } from 'genkit';

const SelectBestCoverShotsInputSchema = z.object({
  photoUrls: z
    .array(z.string().url())
    .describe('An array of photo URLs.'),
});

const SelectBestCoverShotsOutputSchema = z.object({
  coverPhotoUrl: z
    .string()
    .describe('The URL of the single best photo selected for the album cover.'),
});

async function selectBestCoverShots(input) {
  return await selectBestCoverShotsFlow(input);
}

const prompt = ai.definePrompt({
  name: 'selectBestCoverShotsPrompt',
  input: { schema: SelectBestCoverShotsInputSchema },
  output: { schema: SelectBestCoverShotsOutputSchema },
  prompt: `You are an expert photographer. You are creating an album and must pick the best shot from the provided images to use for the cover.

Given the following images, select the single best image based on sharpness, faces, and lighting.

Images:
{{#each photoUrls}}
Image {{@index}}: {{media url=this}}
{{/each}}

Return ONLY the URL of the selected image in the 'coverPhotoUrl' field.
`,
});

const selectBestCoverShotsFlow = ai.defineFlow(
  {
    name: 'selectBestCoverShotsFlow',
    inputSchema: SelectBestCoverShotsInputSchema,
    outputSchema: SelectBestCoverShotsOutputSchema,
  },
  async (input) => {
    const { output } = await prompt(input);
    return output;
  }
);

export { selectBestCoverShots };
