// layoutAlbum.js

/**
 * Layout photo album spreads based on tags.
 * @param {Array} photos - Array of photos with {url: string, tags: string[]} 
 * @returns {{ spreads: Array<{ layout: string, photoIndices: number[] }> }}
 */
export function layoutAlbum(photos) {
  const spreads = [];
  const usedIndices = new Set();

  const keyTags = ['bride', 'groom', 'couple', 'kiss', 'ceremony', 'vows'];

  photos.forEach((photo, index) => {
    if (usedIndices.has(index)) return;

    const isKeyPhoto = photo.tags.some(tag => keyTags.includes(tag));

    if (isKeyPhoto) {
      spreads.push({ layout: 'single', photoIndices: [index] });
      usedIndices.add(index);
    }
  });

  // Pair non-key photos
  for (let i = 0; i < photos.length; i++) {
    if (usedIndices.has(i)) continue;
    for (let j = i + 1; j < photos.length; j++) {
      if (!usedIndices.has(j)) {
        spreads.push({ layout: 'pair-horizontal', photoIndices: [i, j] });
        usedIndices.add(i);
        usedIndices.add(j);
        break;
      }
    }
  }

  // Any leftover photos (odd count)
  photos.forEach((_, index) => {
    if (!usedIndices.has(index)) {
      spreads.push({ layout: 'single', photoIndices: [index] });
    }
  });

  return { spreads };
}
