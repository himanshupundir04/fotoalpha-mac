'use server';

/**
 * Auto Tag Photos - Genkit AI Flow
 * Tags photos based on their content using Gemini
 */

import { ai } from '../genkit.js'; // Adjusted import path for JS
import { z } from 'genkit';

const AutoTagPhotosInputSchema = z.object({
  photoUrls: z
    .array(z.string().url())  
    .describe('An array of URLs to photos.'),
});

const AutoTagPhotosOutputSchema = z.object({
  photoTags: z.array(
    z.object({
      tags: z.array(z.string()).describe('The tags for one photo.'),
    })
  ).describe(
    'An array of tag objects, one for each photo in the input, in the same order.'
  ),
});

export async function autoTagPhotos(input) {
  return autoTagPhotosFlow(input);
}

const prompt = ai.definePrompt({
  name: 'autoTagPhotosPrompt',
  input: { schema: AutoTagPhotosInputSchema },
  output: { schema: AutoTagPhotosOutputSchema },
  prompt: `You are an expert photo tagger. For each of the following photos, provide a list of relevant tags.
The output must contain a list of tags for each photo, in the same order as the input photos.

{{#each photoUrls}}
Photo {{@index}}: {{media url=this}}
{{/each}}

Please provide a list of tags for each photo.`,
});

const autoTagPhotosFlow = ai.defineFlow(
  {
    name: 'autoTagPhotosFlow',
    inputSchema: AutoTagPhotosInputSchema,
    outputSchema: AutoTagPhotosOutputSchema,
  },
  async (input) => {
    const { output } = await prompt(input);
    return output;
  }
);
