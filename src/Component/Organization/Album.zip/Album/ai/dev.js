import { config } from 'dotenv';
// Register Genkit flows (converted to .js paths)
import './ai/flows/auto-tag-photos.js';
import './ai/flows/select-best-cover-shots.js';
import './ai/flows/group-photos.js';
import './ai/flows/layout-album.js';
config();
