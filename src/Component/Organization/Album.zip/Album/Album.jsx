import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import { CircularProgress } from "@mui/material";
import ErrorOutlineIcon from "@mui/icons-material/ErrorOutline";
import BoltIcon from "@mui/icons-material/Bolt";
import demo from "../../image/demo.jpg";

const baseURL = process.env.REACT_APP_BASE_URL;

function Album() {
  const [event, setEvent] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();
  const [permission, setPermission] = useState(false);

  useEffect(() => {
    fetchEvents();
  }, []);

  const fetchEvents = async () => {
    setLoading(true);
    try {
      const response = await axios.get(`${baseURL}/events/all-events`, {
        headers: {
          Authorization: `Bearer ${localStorage.getItem("token")}`,
          "ngrok-skip-browser-warning": "69420",
        },
      });
      setEvent(response.data.events);
      setLoading(false);
      window.electronAPI.setStore("album", response.data.events);
    } catch (error) {
      setLoading(false);
      const cachedSummary = await window.electronAPI.getStore("album");
      if (cachedSummary) {
        setEvent(cachedSummary);
        // console.log(cachedSummary);
      }
      // console.error("Error fetching:", error.response.data.message);
      const errorMessage = error?.response?.data?.message || "";
      const statusCode = error?.response?.status;

      if (
        statusCode === 403 ||
        errorMessage ===
          "Your trial period has ended. Please upgrade to continue." ||
        errorMessage ===
          "Your trial period of 14 days has ended. Please upgrade to continue."
      ) {
        setPermission(true);
      }
    }
  };

  return (
    <>
      {loading ? (
        <div className="flex justify-center mt-5">
          <CircularProgress />
        </div>
      ) : permission ? ( // <-- check permission first
        <div className="bg-slate-100 p-5 rounded text-center mt-5">
          <ErrorOutlineIcon
            sx={{ fontSize: "50px" }}
            className="text-red-600"
          />
          <h1 className="text-slate-700 font-normal text-2xl">
            You do not have access to this page
          </h1>
          <p className="text-slate-700 font-normal text-sm">
            We're sorry, your plan does not have permission to access this page
          </p>
          <button
            className="bg-blue rounded px-5 py-2 mt-4 text-white font-normal hover:bg-blueHoverHover"
            onClick={() => navigate("/photographer/upgrade_plan")}
          >
            <BoltIcon /> Upgrade Plan
          </button>
        </div>
      ) : event?.length === 0 ? (
        <div className=" text-center w-1/2 m-auto pt-8">
          <p className="text-slate-700 font-medium text-xl dark:text-white">
            No Events to show
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-5 gap-6">
          {event.map((album) => (
            <div
              key={album?._id}
              className="overflow-hidden bg-white rounded-md p-2 border border-slate-200 flex flex-col transition-all duration-300 hover:shadow-xl hover:-translate-y-1 cursor-pointer group dark:bg-slate-800"
              onClick={() => navigate(`/photographer/album/${album?._id}`)}
            >
              <img
                src={album?.firstPhotoSignedUrl || demo}
                alt={`Cover for ${album?.name}`}
                className="h-40 object-cover w-full"
              />
              <h2 className="text-slate-700 px-4 pt-2 font-normal truncate capitalize dark:text-white">
                {album?.name}
              </h2>
              {/* <div className="flex justify-end px-4 pb-4 pt-2">
              <div className="flex items-center gap-1 text-slate-700 font-normal md:opacity-0 md:group-hover:opacity-100 transition-opacity dark:text-white">
                <p>View Album</p>
                <ArrowForwardIcon className="h-4 w-4" />
              </div>
            </div> */}
            </div>
          ))}
        </div>
      )}
    </>
  );
}

export default Album;
